const express = require('express');
const Receiver = require('../models/Receiver');
const router = express.Router();

// Create Receiver
router.post('/', async (req, res) => {
  try {
    console.log("Creating new receiver:", req.body);
    const receiver = new Receiver(req.body);
    await receiver.save();
    res.status(201).json(receiver);
  } catch (error) {
    console.error("Error creating receiver:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Get All Receivers
router.get('/', async (req, res) => {
  try {
    const receivers = await Receiver.find();
    res.json(receivers);
  } catch (error) {
    console.error("Error fetching receivers:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Update Receiver
router.put('/:id', async (req, res) => {
  try {
    const receiver = await Receiver.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(receiver);
  } catch (error) {
    console.error("Error updating receiver:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Delete Receiver
router.delete('/:id', async (req, res) => {
  try {
    await Receiver.findByIdAndDelete(req.params.id);
    res.json({ message: 'Receiver deleted' });
  } catch (error) {
    console.error("Error deleting receiver:", error.message);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
