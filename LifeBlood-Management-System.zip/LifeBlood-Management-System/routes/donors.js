const express = require('express');
const Donor = require('../models/Donor');
const router = express.Router();

// Create Donor
router.post('/', async (req, res) => {
  try {
    console.log("Creating new donor:", req.body);
    const donor = new Donor(req.body);
    await donor.save();
    res.status(201).json(donor);
  } catch (error) {
    console.error("Error creating donor:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Get All Donors
router.get('/', async (req, res) => {
  try {
    const donors = await Donor.find();
    res.json(donors);
  } catch (error) {
    console.error("Error fetching donors:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Update Donor
router.put('/:id', async (req, res) => {
  try {
    const donor = await Donor.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(donor);
  } catch (error) {
    console.error("Error updating donor:", error.message);
    res.status(500).json({ message: error.message });
  }
});

// Delete Donor
router.delete('/:id', async (req, res) => {
  try {
    await Donor.findByIdAndDelete(req.params.id);
    res.json({ message: 'Donor deleted' });
  } catch (error) {
    console.error("Error deleting donor:", error.message);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
