document.getElementById('donorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const donor = {
      name: document.getElementById('name').value,
      bloodType: document.getElementById('bloodType').value,
      age: parseInt(document.getElementById('age').value),
      gender: document.getElementById('gender').value,
      contactInfo: document.getElementById('contactInfo').value,
      location: document.getElementById('location').value,
    };
    
    console.log("Submitting new donor:", donor);
    
    await fetch('/api/donors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(donor),
    });
    loadDonors();
  });
  
  async function loadDonors() {
    const response = await fetch('/api/donors');
    const donors = await response.json();
    const donorList = document.getElementById('donorList');
    donorList.innerHTML = donors.map(d => `
      <div>
        <p>${d.name} - ${d.bloodType} - ${d.age} - ${d.gender}</p>
        <button onclick="deleteDonor('${d._id}')">Delete</button>
      </div>
    `).join('');
  }
  
  async function deleteDonor(id) {
    await fetch(`/api/donors/${id}`, { method: 'DELETE' });
    loadDonors();
  }
  
  loadDonors();
  