document.getElementById('receiverForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const receiver = {
      name: document.getElementById('name').value,
      bloodType: document.getElementById('bloodType').value,
      age: parseInt(document.getElementById('age').value),
      gender: document.getElementById('gender').value,
      contactInfo: document.getElementById('contactInfo').value,
      location: document.getElementById('location').value,
    };
    
    console.log("Submitting new receiver:", receiver);
    
    await fetch('/api/receivers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(receiver),
    });
    loadReceivers();
  });
  
  async function loadReceivers() {
    const response = await fetch('/api/receivers');
    const receivers = await response.json();
    const receiverList = document.getElementById('receiverList');
    receiverList.innerHTML = receivers.map(r => `
      <div>
        <p>${r.name} - ${r.bloodType} - ${r.age} - ${r.gender}</p>
        <button onclick="deleteReceiver('${r._id}')">Delete</button>
      </div>
    `).join('');
  }
  
  async function deleteReceiver(id) {
    await fetch(`/api/receivers/${id}`, { method: 'DELETE' });
    loadReceivers();
  }
  
  loadReceivers();
  