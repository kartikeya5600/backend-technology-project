const express = require('express');
const mongoose = require('./config/database');
const cors = require('cors');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Routes
app.use('/api/donors', require('./routes/donors'));
app.use('/api/receivers', require('./routes/receivers'));

// Server start
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
