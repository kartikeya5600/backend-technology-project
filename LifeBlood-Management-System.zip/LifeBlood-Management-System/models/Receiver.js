const mongoose = require('mongoose');

const receiverSchema = new mongoose.Schema({
  name: String,
  bloodType: String,
  age: Number,
  gender: String,
  contactInfo: String,
  location: String,
});

module.exports = mongoose.model('Receiver', receiverSchema);
